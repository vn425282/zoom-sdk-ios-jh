//
//  QAListTableViewCell.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2019/10/28.
//  Copyright © 2019 Zoom Video Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface QAListTableViewCell : UITableViewCell
@property (nonatomic, strong) UILabel *contentLabel;
@end

