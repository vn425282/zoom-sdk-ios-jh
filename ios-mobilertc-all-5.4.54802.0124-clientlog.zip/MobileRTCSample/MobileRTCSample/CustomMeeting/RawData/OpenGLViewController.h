//
//  OpenGLViewController.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2019/8/6.
//  Copyright © 2019 Zoom Video Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpenGLViewController : UIViewController

@end

