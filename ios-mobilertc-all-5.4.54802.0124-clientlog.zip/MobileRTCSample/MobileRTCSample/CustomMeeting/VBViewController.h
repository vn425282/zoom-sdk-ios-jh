//
//  VBViewController.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2020/4/7.
//  Copyright © 2020 Zoom Video Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VBViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
