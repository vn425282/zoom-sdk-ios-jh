//
//  InterpreterLanguageSelectViewController.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2020/10/27.
//  Copyright © 2020 Zoom Video Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface InterpreterLanguageSelectViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
