//
//  SelectLanInterpreViewController.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2020/10/22.
//  Copyright © 2020 Zoom Video Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectLanguageViewController : UIViewController
@property (nonatomic, assign)   NSInteger             currentLanID;
@end

