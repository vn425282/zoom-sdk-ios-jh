//
//  BaseNavigationController.h
//  MobileRTCSample
//
//  Created by Byron Zhang on 2020/8/27.
//  Copyright © 2020 Zoom Video Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseNavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
