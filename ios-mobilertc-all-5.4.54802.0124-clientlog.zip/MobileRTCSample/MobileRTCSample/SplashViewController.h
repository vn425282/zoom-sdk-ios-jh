//
//  SplashViewController.h
//  IntroTest
//
//  Created by Zoom Video Communications on 15/12/2.
//  Copyright © 2015年 Robust. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashViewController : UIViewController

@end
