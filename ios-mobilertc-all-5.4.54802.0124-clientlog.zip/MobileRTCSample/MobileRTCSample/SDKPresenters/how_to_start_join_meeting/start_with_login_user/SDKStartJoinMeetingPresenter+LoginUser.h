//
//  SDKStartJoinMeetingPresenter+LoginUser.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2018/11/19.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import "SDKStartJoinMeetingPresenter.h"

@interface SDKStartJoinMeetingPresenter (LoginUser)

- (void)startMeeting_emailLoginUser:(BOOL)appShare;

@end
