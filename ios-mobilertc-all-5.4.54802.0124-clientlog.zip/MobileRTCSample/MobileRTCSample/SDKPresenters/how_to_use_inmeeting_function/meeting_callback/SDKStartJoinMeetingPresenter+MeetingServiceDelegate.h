//
//  SDKStartJoinMeetingPresenter+MeetingServiceDelegate.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2018/11/21.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import "SDKStartJoinMeetingPresenter.h"
#import <MobileRTC/MobileRTCMeetingDelegate.h>

@interface SDKStartJoinMeetingPresenter (MeetingServiceDelegate)<MobileRTCMeetingServiceDelegate>

@end

