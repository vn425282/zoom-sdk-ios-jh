//
//  SDKStartJoinMeetingPresenter+Interpretation.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2020/10/28.
//  Copyright © 2020 Zoom Video Communications, Inc. All rights reserved.
//

#import "SDKStartJoinMeetingPresenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface SDKStartJoinMeetingPresenter (Interpretation) <MobileRTCMeetingServiceDelegate>

@end

NS_ASSUME_NONNULL_END
