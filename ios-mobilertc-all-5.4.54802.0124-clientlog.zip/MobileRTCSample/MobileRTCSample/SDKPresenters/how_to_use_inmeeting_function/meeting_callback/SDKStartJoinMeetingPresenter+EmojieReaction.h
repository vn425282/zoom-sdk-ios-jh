//
//  SDKStartJoinMeetingPresenter+EmojieReaction.h
//  MobileRTCSample
//
//  Created by Zoom Video Communication on 2020/12/3.
//  Copyright © 2020 Zoom Video Communications, Inc. All rights reserved.
//

#import "SDKStartJoinMeetingPresenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface SDKStartJoinMeetingPresenter (EmojieReaction)

@end

NS_ASSUME_NONNULL_END
