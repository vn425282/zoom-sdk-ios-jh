//
//  SDKStartJoinMeetingPresenter+UserServiceDelegate.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2018/11/30.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import "SDKStartJoinMeetingPresenter.h"

@interface SDKStartJoinMeetingPresenter (UserServiceDelegate)<MobileRTCMeetingServiceDelegate>

@end

