//
//  SDKAuthPresenter+authDelegate.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 2018/11/21.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import "SDKAuthPresenter.h"

@interface SDKAuthPresenter (AuthDelegate)<MobileRTCAuthDelegate, MobileRTCPremeetingDelegate>

@end
