//
//  InviteViewController.h
//  MobileRTCSample
//
//  Created by Zoom Video Communications on 7/30/15.
//  Copyright (c) 2015 Zoom Video Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InviteViewController : UIViewController

@end
