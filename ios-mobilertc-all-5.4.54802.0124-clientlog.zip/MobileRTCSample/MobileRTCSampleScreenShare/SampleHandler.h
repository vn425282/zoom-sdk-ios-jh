//
//  SampleHandler.h
//  ExtensionReplayKit
//
//  Created by Zoom Video Communications on 2018/5/11.
//  Copyright © 2018 Zoom Video Communications, Inc. All rights reserved.
//

#import <ReplayKit/ReplayKit.h>

@interface SampleHandler : RPBroadcastSampleHandler

@end
